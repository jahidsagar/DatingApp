<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">Dating Site</a>
        </div>
        <ul class="nav navbar-nav navbar-right">
            <?php if(request()->is('/')): ?>
                <li><a href="signin">Sign in</a></li>
            <?php endif; ?>
            <?php if(request()->is('/signin')): ?>
                <li><a href="/">Register</a></li>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
                <li class="form-group">
                    <input type="text" class="form-control navbar-btn" placeholder="Search..." id="search">
                </li>
                <li>&nbsp;</li>
                <li>
                <form action="<?php echo e(URL::to('/logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-danger navbar-btn">Log out</button>
                </form>
            </li>
            <?php endif; ?>
        </ul>
        
    </div>
</nav><?php /**PATH F:\blog\resources\views/static/navbar.blade.php ENDPATH**/ ?>
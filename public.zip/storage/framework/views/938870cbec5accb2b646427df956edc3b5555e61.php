<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('static.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        .success{
            color: red;
        }
        @media  screen and (max-width: 995px) {
            .right {
                float: right;
            }
        }
    </style>
    <title>Welcome to Dating Site</title>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <?php echo $__env->make('static.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <?php if(Session::has('image')): ?>
                <h4 class="text-center text-success"><?php echo e(Session::get('image')); ?></h4>
            <?php endif; ?>
            <?php $__errorArgs = ['userImage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <h4 class="text-center text-success"><?php echo e(error('userImage')); ?></h4>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="col-md-4">
                <?php
                $link = auth::user()->id.".jpeg";
                ?>
                <img src="<?php echo e(asset('image')); ?>/<?php echo e($link); ?>" class="img-thumbnail" width="200" height="200"
                    alt="please upload image">
                
                <div class="card right" style="width: 18rem;">
                    <form action="<?php echo e(URL::to('/imageupload')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="userImage">Upload image</label>
                            <input type="file" class="form-control-file" id="userImage" name="userImage" accept="image/jpeg" required>
                            <button type="submit" class="btn btn-info navbar-btn">Submit</button>
                        </div>
                    </form>
                    <ul class="list-group list-group-flush ">
                        <li class="list-group-item"><b>Name: </b><?php echo e(Auth::user()->name); ?></li>
                        <li class="list-group-item"><b>Gender: </b><?php echo e(Auth::user()->gender); ?></li>
                        <li class="list-group-item"><b>Birth date: </b><?php echo e(Auth::user()->dob); ?></li>
                        <?php
                        $dob = Auth::user()->dob;
                        $dob = explode("-", $dob);
                        $age = (date("md", date("U", mktime(0, 0, 0, $dob[1], $dob[2], $dob[0]))) >
                        date("md")
                        ? ((date("Y") - $dob[0]) - 1)
                        : (date("Y") - $dob[0]));
                        ?>
                        <li class="list-group-item"><b>Age: </b><?php echo e($age); ?></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-8">
                <table class="table table-striped" id="usersTable">
                    <thead>
                        <tr>
                            
                            <th scope="col">Name</th>
                            <th scope="col">Gender</th>
                            <th scope="col">Age</th>
                            <th scope="col">Distance (Km)</th>
                            <th scope="col">Image</th>
                            <th scope="col">Liked</th>
                        </tr>
                    </thead>
                    <tbody>
                        

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
<?php echo $__env->make('static.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('static.userjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</html>
<?php /**PATH F:\blog\resources\views/user.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('static.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Welcome to Dating Site</title>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <nav class="navbar navbar-default">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <a class="navbar-brand" href="#">Dating Site</a>
                    </div>
                    <ul class="nav navbar-nav navbar-right">
                        <?php if(request()->is('/')): ?>
                            <li><a href="signin">Sign in</a></li>
                        <?php endif; ?>
                        <?php if(request()->is('signin')): ?>
                            <li><a href="/">Register</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </nav>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-2"></div>
            <form action="<?php echo e(URL::to('/login')); ?>" name="signin" class="col-md-4 col-sm-8" method="POST">
                <?php echo csrf_field(); ?>
                
                <?php if(Session::has('registration')): ?>
                <h4 class="text-center text-success"><?php echo e(Session::get('registration')); ?></h4>
                <?php endif; ?>
                <?php if(Session::has('signin_error')): ?>
                <h4 class="text-center text-danger"><?php echo e(Session::get('signin_error')); ?></h4>
                <?php endif; ?>
                <h3 class="text-center">Please sign in</h3>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email"
                        required>
                    <p class="text-danger" id="error_name"></p>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" class="form-control" id="password" name="password"
                        placeholder="Enter your password" required>
                    <p class="text-danger" id="error_password"></p>
                </div>
                
                <button type="submit" class="btn btn-default">Submit</button>
            </form>
        </div>
    </div>
</body>
<?php echo $__env->make('static.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>

</script>

</html>
<?php /**PATH F:\blog\resources\views/signin.blade.php ENDPATH**/ ?>